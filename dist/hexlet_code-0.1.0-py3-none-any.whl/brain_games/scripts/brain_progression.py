from brain_games.progression import progression_game


def main():
    print("Welcome to the Brain Games!")
    progression_game()


if __name__ == '__main__':
    main()
