from brain_games.calc import calc_game


def main():
    print("Welcome to the Brain Games!")
    calc_game()


if __name__ == '__main__':
    main()
