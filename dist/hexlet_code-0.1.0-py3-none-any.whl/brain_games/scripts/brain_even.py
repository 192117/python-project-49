from brain_games.even import even_game


def main():
    print("Welcome to the Brain Games!")
    even_game()


if __name__ == '__main__':
    main()
