from brain_games.progression import progression


def main():
    print("Welcome to the Brain Games!")
    progression()


if __name__ == '__main__':
    main()
