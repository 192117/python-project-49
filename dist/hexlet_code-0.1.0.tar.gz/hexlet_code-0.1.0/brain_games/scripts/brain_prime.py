from brain_games.prime import prime_game


def main():
    print("Welcome to the Brain Games!")
    prime_game()


if __name__ == '__main__':
    main()
