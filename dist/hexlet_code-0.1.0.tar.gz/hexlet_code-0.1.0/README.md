### Hexlet tests and linter status:
[![Actions Status](https://github.com/192117/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/192117/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/f2b6b5dbbbefd367281f/maintainability)](https://codeclimate.com/github/192117/python-project-49/maintainability)

